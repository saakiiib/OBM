const $ = s => document.querySelector(s);
function safe(v){return v||'Not available yet'}
function listingCard(x){return `<a class="directory-card org-card" href="listing.html?id=${encodeURIComponent(x.id)}" data-search="${(x.name+' '+x.bn+' '+x.category+' '+x.subcategory+' '+x.district+' '+x.division).toLowerCase()}"><div class="directory-icon">${x.icon}</div><div class="directory-copy"><strong>${x.name}</strong>${x.bn?`<span>${x.bn}</span>`:''}<span>${x.subcategory} · ${x.district}</span><span class="tag">View profile</span></div></a>`}
function newspaperCard(x){return `<a class="directory-card org-card" target="_blank" rel="noopener" href="${x.website}" data-search="${(x.name+' '+x.bn+' '+x.type).toLowerCase()}"><div class="directory-icon">📰</div><div class="directory-copy"><strong>${x.name}</strong>${x.bn?`<span>${x.bn}</span>`:''}<span>${x.type}</span><span class="tag">Visit website ↗</span></div></a>`}
function filterCards(q){q=q.trim().toLowerCase();document.querySelectorAll('.org-card').forEach(el=>{el.style.display=!q||(el.dataset.search||'').includes(q)?'flex':'none'});}

document.addEventListener('DOMContentLoaded',()=>{
  const grid=$('#directoryGrid'); if(grid) grid.innerHTML=portalListings.map(listingCard).join('');
  const papers=$('#paperGrid'); if(papers) papers.innerHTML=newspaperListings.map(newspaperCard).join('');
  const form=$('#directorySearch'); if(form) form.addEventListener('submit',e=>{e.preventDefault();filterCards($('#directoryQuery').value)});
  const input=$('#directoryQuery'); if(input) input.addEventListener('input',e=>filterCards(e.target.value));
  const emergency=$('#emergencyGrid'); if(emergency) emergency.innerHTML=emergencyLinks.map(([n,t,d])=>`<article class="emergency-card"><b>${n}</b><div><strong>${t}</strong><span>${d}</span></div><a href="tel:${n}">Call</a></article>`).join('');
});
