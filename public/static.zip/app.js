const quickCategories = [
  ['📰','Newspapers'],['📺','TV Channels'],['📻','Radio'],['🎓','Universities'],['🏥','Hospitals'],['🏛️','Government'],['💼','Jobs'],['✈️','Travel'],['🏦','Banks'],['👥','Embassies'],['🌐','Scholarships'],['•••','More']
];
const news = {
  bangla:[
    ['🌉','পদ্মা সেতু অর্থনীতিতে নতুন দিগন্ত খুলেছে: বিশেষজ্ঞরা','প্রথম আলো','২ ঘণ্টা আগে'],
    ['🏏','বাংলাদেশের দারুণ জয়, সিরিজে এগিয়ে টাইগাররা','সমকাল','৩ ঘণ্টা আগে'],
    ['🏫','নতুন শিক্ষাবর্ষে বিশ্ববিদ্যালয়ে ভর্তি নিয়ে নতুন নির্দেশনা','কালের কণ্ঠ','৬ ঘণ্টা আগে'],
    ['🌿','সুন্দরবন সংরক্ষণে নতুন উদ্যোগ নেবে সরকার','বাংলাদেশ প্রতিদিন','৬ ঘণ্টা আগে']
  ],
  english:[
    ['🏙️','Bangladesh economy shows fresh signs of resilience','The Daily Star','2 hours ago'],
    ['🚆','New infrastructure projects set to improve connectivity','Dhaka Tribune','4 hours ago'],
    ['🎓','Universities announce updated admission schedules','The Financial Express','5 hours ago'],
    ['🌾','Agriculture sector sees stronger digital adoption','The Business Standard','7 hours ago']
  ],
  international:[
    ['🌍','Bangladesh expands international trade partnerships','International Desk','1 hour ago'],
    ['✈️','New air routes strengthen links with Bangladesh','Travel Desk','3 hours ago'],
    ['🤝','Development partners announce new Bangladesh programmes','World News','5 hours ago'],
    ['📈','Regional markets watch Bangladesh growth outlook','Global Business','8 hours ago']
  ]
};
news.all = [...news.bangla.slice(0,2), ...news.english.slice(0,2)];
const newspapers = [['প্রথম আলো','bn'],['সমকাল','bn'],['বাংলাদেশ প্রতিদিন','bn'],['যুগান্তর','bn'],['কালের কণ্ঠ','bn'],['The Daily Star',''],['ইত্তেফাক','bn'],['Dhaka Tribune','']];
const localJobs=[['🌸','BRAC','Programme Officer','Dhaka','12 Sep 2026'],['🏦','Bangladesh Bank','Assistant Director','Dhaka','18 Sep 2026'],['🔷','Grameenphone','Software Engineer','Dhaka','20 Sep 2026']];
const overseasJobs=[['🇸🇦','Almarai (Saudi Arabia)','Various Positions','Saudi Arabia','15 Sep 2026'],['✈️','Qatar Airways','Cabin Crew','Qatar','22 Sep 2026'],['🇬🇧','NHS (UK)','Nurse - International Recruitment','United Kingdom','30 Sep 2026']];
const scholarships=[['🎓','Chevening Scholarship','United Kingdom','Fully Funded',''],['🔵','DAAD Scholarship','Germany','Fully Funded',''],['🇦🇺','Australia Awards','Australia','Fully Funded','']];
const explore=[['🏫','Colleges'],['🩺','Medical Colleges'],['📄','Education Boards'],['🔬','Diagnostic Centres'],['✈️','Airlines'],['🚆','Railway'],['🚌','Bus Services'],['🏨','Hotels'],['📈','Stock Exchange'],['🛡️','Insurance'],['🤲','NGOs'],['🌐','Bangladeshi Media Abroad']];
const tv=[['📺','ATN Bangla'],['🟢','Channel i'],['🟥','Somoy TV'],['⭕','Independent TV']];
const unis=[['🏛️','University of Dhaka'],['🧱','BUET'],['🏫','Jahangirnagar University'],['🎓','BRAC University']];
const gov=[['🪪','NID'],['🛂','Passport'],['💻','e-Return'],['📜','Birth Registration']];

const $=s=>document.querySelector(s); const $$=s=>document.querySelectorAll(s);
function renderQuick(){ const pageMap={'Newspapers':'news-media.html','TV Channels':'news-media.html','Radio':'news-media.html','Universities':'education.html','Hospitals':'health.html','Government':'government.html','Jobs':'jobs.html','Travel':'travel.html','Banks':'business.html','Embassies':'categories.html','Scholarships':'education.html','More':'categories.html'}; $('#quickCategories').innerHTML=quickCategories.map(([i,n])=>`<a class="cat-card searchable" href="${pageMap[n]||'categories.html'}" data-search="${n.toLowerCase()}"><span class="emoji">${i}</span><span>${n}</span></a>`).join(''); }
function renderNews(tab='bangla'){ $('#newsGrid').innerHTML=news[tab].map(([i,t,s,d])=>`<article class="news-card searchable" data-search="${(t+' '+s).toLowerCase()}"><div class="news-img"><span>${i}</span></div><div class="news-body"><h3>${t}</h3><div class="meta"><b>${s}</b><span>·</span><span>${d}</span></div></div></article>`).join(''); }
function renderNewspapers(){ $('#newspaperGrid').innerHTML=newspapers.map(([n,c])=>`<a class="logo-box searchable ${c}" href="#" data-search="${n.toLowerCase()}">${n}</a>`).join(''); }
function renderList(id,items){ $(id).innerHTML=items.map(([i,n,r,l,d])=>`<div class="list-item searchable" data-search="${(n+' '+r+' '+l).toLowerCase()}"><div class="list-icon">${i}</div><div class="list-copy"><strong>${n}</strong><span>${r}</span><span>⌖ ${l}</span></div>${d?`<div class="list-date">${d}</div>`:''}</div>`).join(''); }
function renderExplore(){ const pageMap={'Colleges':'education.html','Medical Colleges':'education.html','Education Boards':'education.html','Diagnostic Centres':'health.html','Airlines':'travel.html','Railway':'travel.html','Bus Services':'travel.html','Hotels':'travel.html','Stock Exchange':'business.html','Insurance':'business.html','NGOs':'categories.html','Bangladeshi Media Abroad':'news-media.html'}; $('#exploreGrid').innerHTML=explore.map(([i,n])=>`<a href="${pageMap[n]||'categories.html'}" class="explore-card searchable" data-search="${n.toLowerCase()}"><span>${i}</span><b>${n}</b></a>`).join(''); }
function renderMini(id,arr){ $(id).innerHTML=arr.map(([i,n])=>`<a href="#" class="mini-card searchable" data-search="${n.toLowerCase()}"><span>${i}</span><b>${n}</b></a>`).join(''); }
function toast(msg){ const t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(window.__toast);window.__toast=setTimeout(()=>t.classList.remove('show'),2500); }
function searchPortal(query){ const q=query.trim().toLowerCase(); if(!q){toast('Type something to search.');return;} const items=[...$$('.searchable')]; let first=null,count=0; items.forEach(el=>{const hit=(el.dataset.search||'').includes(q);el.style.outline=hit?'2px solid #e51b36':'';el.style.outlineOffset=hit?'2px':'';if(hit){count++; first ||= el;}}); if(first){first.scrollIntoView({behavior:'smooth',block:'center'});toast(`${count} matching item${count===1?'':'s'} found.`)}else toast(`No demo result for “${query}” yet — real directory data can be added next.`); }

renderQuick();renderNews();renderNewspapers();renderList('#localJobs',localJobs);renderList('#overseasJobs',overseasJobs);renderList('#scholarships',scholarships);renderExplore();renderMini('#tvGrid',tv);renderMini('#uniGrid',unis);renderMini('#govGrid',gov);

$('#newsTabs').addEventListener('click',e=>{if(!e.target.matches('button'))return; $$('#newsTabs button').forEach(b=>b.classList.remove('active'));e.target.classList.add('active');renderNews(e.target.dataset.tab);});
$('#searchForm').addEventListener('submit',e=>{e.preventDefault();searchPortal($('#portalSearch').value)});
$$('.popular-row button').forEach(b=>b.addEventListener('click',()=>{$('#portalSearch').value=b.dataset.query;searchPortal(b.dataset.query)}));
$('#navSearchBtn').addEventListener('click',()=>{$('#portalSearch').focus();$('.hero').scrollIntoView({behavior:'smooth'});});
$('#menuButton').addEventListener('click',()=>$('#mainNav').classList.toggle('open'));
$('#mainNav').addEventListener('click',()=>$('#mainNav').classList.remove('open'));
$('#themeToggle').addEventListener('click',()=>{document.body.classList.toggle('dark');$('#themeToggle').textContent=document.body.classList.contains('dark')?'☀':'☾';});
$('#subscribeForm').addEventListener('submit',e=>{e.preventDefault();toast('Thank you — subscription demo submitted.');e.target.reset();});


function renderHomeDirectory(){
  const el=document.querySelector('#homeDirectoryGrid');
  if(!el || typeof portalListings==='undefined') return;
  const priority=['university-of-dhaka','square-hospital','bangladesh-bank','biman-bangladesh','passport-bangladesh','bangladesh-high-commission-london','brac','bangladesh-railway'];
  const items=priority.map(id=>portalListings.find(x=>x.id===id)).filter(Boolean);
  el.innerHTML=items.map(x=>`<a class="home-directory-card searchable" href="listing.html?id=${encodeURIComponent(x.id)}" data-search="${(x.name+' '+x.category+' '+x.subcategory+' '+x.district).toLowerCase()}"><span class="ico">${x.icon}</span><div><b>${x.name}</b><span>${x.subcategory} · ${x.district}</span></div></a>`).join('');
}
function renderHomeEmergency(){
  const el=document.querySelector('#homeEmergencyGrid');
  if(!el || typeof emergencyLinks==='undefined') return;
  el.innerHTML=emergencyLinks.slice(0,6).map(([n,t])=>`<a class="emergency-pill" href="tel:${n}"><b>${n}</b><span>${t}</span></a>`).join('');
}
renderHomeDirectory();
renderHomeEmergency();
